# Java_Module
Classes-object ---Activity=1
##
Inheritance    ---Activity=2
##
Abstract class ---Activity=3
