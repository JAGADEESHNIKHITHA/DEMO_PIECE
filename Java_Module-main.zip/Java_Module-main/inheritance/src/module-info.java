module inheritance {
}